# 1. Installing Microthemer
Microthemer is installed in the same way as any other WordPress plugin. The simplest method is this:

- Log in to your WordPress dashboard.
- Ensure that you are using WordPress version 5.5 or higher.
- In the left hand WordPress menu click Plugins > Add new.
- Click the upload link near the top of the page.
- Using the file upload button, navigate to where you downloaded the zip file you got when you downloaded Microthemer.
- Once you've selected the zip file, click the "Install now" button.
- When the plugin has finished installing, click the "Activate Plugin" link.

# 2. Read the documentation and tutorials
Learn how to use Microthemer here: http://themeover.com/support/

# 3. Get help
You can get free support from Themeover's support forum: http://themeover.com/forum/