<?php
/**
 * This file provides access to all publicly exposed functions.
 */

require_once POSTEXPIRATOR_BASEDIR . '/legacy-functions.php';
