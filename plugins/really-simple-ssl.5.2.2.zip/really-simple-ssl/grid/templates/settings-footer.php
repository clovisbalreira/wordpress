<?php defined('ABSPATH') or die("you do not have access to this page!"); ?>

<input class="button button-rsssl-secondary rsssl-button-save" name="Submit" type="submit" value="<?php echo __("Save", "really-simple-ssl"); ?>"/>
