<?php

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Radio_Player_Elementor_Widget' ) ) {
	class Radio_Player_Elementor_Widget extends \Elementor\Widget_Base {

		public function get_name() {
			return 'radio_player';
		}

		public function get_title() {
			return __( 'Radio Player', 'radio-player' );
		}

		public function get_icon() {
			return 'eicon-play';
		}

		public function get_categories() {
			return [ 'basic' ];
		}

		public function get_keywords() {
			return [ 'audio', 'radio', 'music', 'radio-player', 'radio player' ];
		}

		public function _register_controls() {

			$this->start_controls_section( '_section_radio_player',
				[
					'label' => __( 'Radio Player', 'radio-player' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				] );


			$this->add_control( 'player_id',
				[
					'label'       => __( 'Select Player', 'radio-player' ),
					'type'        => Controls_Manager::SELECT,
					'label_block' => true,
					'options'     => get_players_array()
				] );


			$this->end_controls_section();
		}

		public function render() {
			$settings = $this->get_settings_for_display();
			extract( $settings );

			echo do_shortcode( "[radio_player id={$player_id} player_type=shortcode autoplay=off]" );
		}

	}
}