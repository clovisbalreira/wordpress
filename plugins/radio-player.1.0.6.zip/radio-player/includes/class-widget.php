<?php

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Radio_Player_Widget' ) ) {
	class Radio_Player_Widget extends WP_Widget {

		/**
		 * @var null
		 */
		private static $instance = null;

		/**
		 * Sets up the widgets name etc
		 */
		public function __construct() {
			$widget_ops = array(
				'classname'   => 'radio_player_widget',
				'description' => esc_html__( 'Display radio player.', 'radio-player' ),
			);

			parent::__construct( 'radio_player', __( 'Radio Player', 'radio-player' ), $widget_ops );

			add_action( 'widgets_init', [ $this, 'register_widget' ] );
		}

		/**
		 * Outputs the content of the widget
		 *
		 * @param array $args
		 * @param array $instance
		 *
		 * @since 1.0.0
		 */
		public function widget( $args, $instance ) {

			$id = ! empty( $instance['player_id'] ) ? $instance['player_id'] : '';

			echo $args['before_widget'];
			if ( ! empty( $instance['title'] ) ) {
				echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
			}

			if ( ! $id ) {
				esc_html_e( 'Please select a radio player in the widget settings.', 'radio-player' );
			} else {
				echo do_shortcode( '[radio_player id="' . $id . '" player_type="shortcode" ]' );
			}

			echo $args['after_widget'];
		}

		/**
		 * Outputs the options form on admin
		 *
		 * @param array $instance The widget options
		 *
		 */
		public function form( $instance ) {
			$title       = ! empty( $instance['title'] ) ? $instance['title'] : '';
			$selected_id = ! empty( $instance['player_id'] ) ? $instance['player_id'] : '';
			?>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'radio-player' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                       name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
                       value="<?php echo esc_attr( $title ); ?>">
            </p>

            <p class="radio_player_widget">
                <label for="<?php echo esc_attr( $this->get_field_id( 'player_id' ) ); ?>"><?php esc_html_e( 'Select Player:', 'radio-player' ); ?></label>

                <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'player_id' ) ); ?>"
                        name="<?php echo esc_attr( $this->get_field_name( 'player_id' ) ); ?>">
					<?php

					if ( ! empty( radio_player_get_player_ids() ) ) {

						foreach ( radio_player_get_player_ids() as $player_id ) {
							printf( '<option value="%1$s" %2$s>%3$s</option>',
								$player_id,
								selected( $player_id, $selected_id, false ),
								get_the_title( $player_id ) );
						}

					}

					?>
                </select>
                <span><?php _e( 'Select the radio player.', 'radio-player' ); ?></span>
            </p>
			<?php
		}

		/**
		 * Processing widget options on save
		 *
		 * @param array $new_instance The new options
		 * @param array $old_instance The previous options
		 *
		 * @return array
		 */
		public function update( $new_instance, $old_instance ) {
			$instance              = array();
			$instance['title']     = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
			$instance['player_id'] = ( ! empty( $new_instance['player_id'] ) ) ? intval( $new_instance['player_id'] ) : '';

			return $instance;
		}

		/**
		 * Register widget
		 */
		public function register_widget() {
			register_widget( __CLASS__ );
		}

		/**
		 * @return Radio_Player_Widget|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

	}
}

Radio_Player_Widget::instance();
