<?php

defined( 'ABSPATH' ) || exit;
if ( !class_exists( 'Radi_Playero_Statistics' ) ) {
    class Radio_Player_Statistics
    {
        private static  $instance = null ;
        protected  $query_args = array() ;
        public function __construct( $args )
        {
            $this->query_args = $args;
        }
        
        public function filter_bar()
        {
            ?>
            <div class="radio-player-filter-bar" id="radio_player_statistics_filter">

                <p class="description">
					<?php 
            _e( 'Select specific dates to filter the statistics data.', 'radio-player' );
            ?>
                </p>

                <form action="" method="get">
                    <div class="input-group">

                        <div class="form-group">
                            <label for="start_date"><?php 
            _e( 'Start Date:', 'radio-player' );
            ?></label>
                            <input type="text" id="start_date" class="radio_player_date_field" name="start_date"
                                   value="<?php 
            echo  $this->query_args['start_date'] ;
            ?>">
                        </div>

                        <div class="form-group">
                            <label for="end_date"><?php 
            _e( 'End Date:', 'radio-player' );
            ?></label>
                            <input type="text" id="end_date" class="radio_player_date_field" name="end_date"
                                   value="<?php 
            echo  $this->query_args['end_date'] ;
            ?>">
                        </div>

                        <div class="form-group">
                            <button type="submit" class="statistics_filter_submit button button-primary button-large">
                                <i class="dashicons dashicons-filter"></i> <?php 
            _e( 'Filter', 'radio-player' );
            ?></button>
                        </div>

                    </div>

                    <input type="hidden" name="post_type" value="radio">
                    <input type="hidden" name="page" value="statistics">
                </form>
            </div>
		<?php 
        }
        
        public function log_chart()
        {
            $days = [];
            for ( $i = 0 ;  $i < 15 ;  $i++ ) {
                $days[] = date( "Y-m-d", strtotime( '-' . $i . ' days' ) );
            }
            $dates = array_merge( range( 1500, 2500, 100 ), range( 700, 3000, 300 ) );
            $chart['values'] = '["' . implode( '", "', $dates ) . '"]';
            $chart['labels'] = '["' . implode( '", "', $days ) . '"]';
            return $chart;
        }
        
        public function chart()
        {
            ?>
            <div class="chart-container">
                <canvas height="300" id="radio_player_stats" data-labels='<?php 
            echo  $this->log_chart()['labels'] ;
            ?>'
                        data-values='<?php 
            echo  $this->log_chart()['values'] ;
            ?>'></canvas>
            </div>
		<?php 
        }
        
        public function get_top_players()
        {
            global  $wpdb ;
            $table = $wpdb->prefix . 'radio_player_statistics';
            $page = ( !empty($this->query_args['page']) ? intval( $this->query_args['page'] ) : 1 );
            $per_page = ( !empty($this->query_args['per_page']) ? intval( $this->query_args['per_page'] ) : 50 );
            $start_date = esc_attr( $this->query_args['start_date'] );
            $end_date = esc_attr( $this->query_args['end_date'] );
            $offset = $per_page * ($page - 1);
            $where = "WHERE (`updated_at` BETWEEN '{$start_date}' AND '{$end_date}') ";
            if ( !empty($this->query_args['where']) ) {
                $where .= $this->query_args['where'];
            }
            $sql = "SELECT\r\n                DISTINCT `player_id`,\r\n                COUNT(`id`) AS `total_uniques`,\r\n                SUM(`count`) AS `total_sessions`\r\n            FROM {$table} {$where}\r\n            GROUP BY `player_id`\r\n            ORDER BY\r\n                `total_sessions` DESC,\r\n                `total_uniques` DESC\r\n            LIMIT {$offset}, {$per_page}\r\n            ";
            return $wpdb->get_results( $sql );
        }
        
        public function top_players()
        {
            $players = [ 'Fox News', 'BBC Radio', 'Radio Amazon' ];
            ?>
            <div class="statistics-top-stations <?php 
            echo  ( !empty($players) ? '' : 'hidden' ) ;
            ?>">

                <div class="statistics-table-header">
                    <h3 class="statistics-table-title"><?php 
            _e( 'Most Listened Players', 'radio-player' );
            ?></h3>
                    <p class="description"><?php 
            _e( 'Lists of the top played radio player.', 'radio-player' );
            ?></p>
                </div>

                <table class="widefat" id="top-pages-table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th><?php 
            _e( 'Station', 'radio-player' );
            ?></th>
                        <th>
							<?php 
            _e( 'Listeners Count', 'radio-player' );
            ?>
                            <i class="dashicons dashicons-info rp-tooltip">
                                <span class="tooltiptext"><?php 
            _e( 'Total number of listeners.', 'radio-player' );
            ?></span>
                            </i>
                        </th>
                        <th>
							<?php 
            _e( 'Play Count', 'radio-player' );
            ?>
                            <i class="dashicons dashicons-info rp-tooltip">
                                <span class="tooltiptext"><?php 
            _e( 'The number of times the player has been played.', 'radio-player' );
            ?></span>
                            </i>
                        </th>
                    </tr>
                    </thead>

                    <tbody>

					<?php 
            
            if ( !empty($players) ) {
                $i = 1;
                foreach ( $players as $item ) {
                    $name = $item;
                    $link = '#';
                    $total_listeners = mt_rand( 3000, 15000 );
                    $total_played = mt_rand( 8700, 100000 );
                    ?>
                            <tr>
                                <td><?php 
                    echo  $i ;
                    ?></td>
                                <td><a href="<?php 
                    echo  $link ;
                    ?>"><?php 
                    echo  $name ;
                    ?></a></td>
                                <td><?php 
                    echo  $total_listeners ;
                    ?></td>
                                <td><?php 
                    echo  $total_played ;
                    ?></td>
                            </tr>
							<?php 
                    $i++;
                }
            }
            
            ?>

                    </tbody>
                </table>
            </div>
		<?php 
        }
        
        public static function instance( $args = array() )
        {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self( $args );
            }
            return self::$instance;
        }
    
    }
}