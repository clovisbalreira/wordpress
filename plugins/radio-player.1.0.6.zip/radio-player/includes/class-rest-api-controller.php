<?php

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Radio_Player_Rest_Api_Controller' ) ) {
	class Radio_Player_Rest_Api_Controller extends WP_REST_Controller {
		/** @var null */
		private static $instance = null;

		/**
		 * Radio_Player_Rest_Api_Controller constructor.
		 */
		public function __construct() {
			$this->namespace = 'radio-player/v1';

		}

		/**
		 * Register REST API routes
		 *
		 * @since 1.0.0
		 */
		public function register_routes() {

			//get all players
			register_rest_route( $this->namespace, '/player/all', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_all_player' ),
					'permission_callback' => '__return_true',
				),
			) );

			//get player by id
			register_rest_route( $this->namespace, '/player/(?P<id>\d+)', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_player' ),
					'permission_callback' => '__return_true',
					'args'                => $this->get_collection_params()
				),
			) );

			//get player data
			register_rest_route( $this->namespace, '/player-data/(?P<id>\d+)', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_player_data' ),
					'permission_callback' => '__return_true',
				),
			) );

			//update player data
			register_rest_route( $this->namespace, '/player-data/(?P<id>\d+)', array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'set_player_data' ),
					'permission_callback' => array( $this, 'check_permission' )
				),
			) );


			//get settings
			register_rest_route( $this->namespace, '/settings/', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_settings' ),
					'permission_callback' => '__return_true',
				),
			) );

			//update settings
			register_rest_route( $this->namespace, '/settings/', array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_settings' ),
					'permission_callback' => array( $this, 'check_permission' ),
				),
			) );

			//delete player
			register_rest_route( $this->namespace, '/delete-player/(?P<id>\d+)', array(
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_player' ),
					'permission_callback' => array( $this, 'check_delete_permission' ),
				),
			) );


			//handle notice
			register_rest_route( $this->namespace, '/handle-notice/', array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'handle_notice' ),
					'permission_callback' => array( $this, 'check_permission' ),
				),
			) );

			// register [POST] route to save statistics data
			register_rest_route( $this->namespace, '/statistics/', array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_statistics' ),
					'permission_callback' => '__return_true',
				),
			) );

			register_rest_route( $this->namespace, '/chart-data/(?P<days>\d+)', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_chart' ),
					'permission_callback' => 'is_user_logged_in',
				),
			) );

		}

		public function get_chart( $request ) {

			$days = ! empty( $request['days'] ) ? intval( $request['days'] ) : 30;

			if ( ! class_exists( 'Radio_Player_Statistics' ) ) {
				include_once RADIO_PLAYER_INCLUDES . '/class-statistics.php';
			}

			$args = [
				'start_date' => date( 'Y-m-d', strtotime( "-$days Days" ) ),
				'end_date'   => date( 'Y-m-d', strtotime( 'tomorrow' ) ),
			];


			$obj = Radio_Player_Statistics::instance( $args );

			ob_start();
			$obj->chart();
			$html = ob_get_clean();

			wp_send_json_success( $html );
		}

		public function save_statistics( $request ) {
			$data = json_decode( $request->get_body() );

			$user_ip   = ! empty( $data->ip ) ? sanitize_text_field( $data->ip ) : '';
			$player_id = ! empty( $data->id ) ? intval( $data->id ) : '';

			if ( ! $player_id ) {
				wp_send_json_error( 'Empty player ID' );
			}

			$date = date( 'Y-m-d' );

			$unique_id = md5( $date . $player_id . $user_ip );

			global $wpdb;
			$table = $wpdb->prefix . 'radio_player_statistics';

			$sql = "INSERT INTO 
                        {$table} (`player_id`,`unique_id`, `user_ip`, `created_at`, `updated_at`) 
                    VALUES 
                        (%d, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        `count` = `count` + 1,
                        `updated_at` = VALUES (updated_at)  
                ";

			$wpdb->query( $wpdb->prepare( $sql, [
				$player_id,
				$unique_id,
				$user_ip,
				$date,
				$date
			] ) );

			//listen count
			$sql          = $wpdb->prepare( "SELECT SUM(`count`) FROM {$table} WHERE player_id = %d LIMIT 1;", $player_id );
			$listen_count = $wpdb->get_var( $sql );

			update_post_meta( $player_id, 'listen_count', $listen_count );

			wp_send_json_success();
		}

		public function handle_notice( $request ) {
			$data = json_decode( $request->get_body() );

			$type  = $data->type;
			$value = $data->value;

			if ( 'rating' == $type ) {
				if ( 'hide_notice' == $value ) {
					update_option( 'radio_player_rating_notice', 'off' );
				} else {
					set_transient( 'radio_player_rating_notice_interval', 'off', $value * DAY_IN_SECONDS );
				}
			}

			update_option( sanitize_key( 'radio_player_notices' ), [] );

		}

		public function delete_player( $data ) {
			$player_id = isset( $data['id'] ) ? $data['id'] : '';

			if ( $player_id ) {
				wp_delete_post( $player_id, true );
			}

			wp_send_json_success();
		}

		public function update_settings( $request ) {
			$posted = json_decode( $request->get_body() );

			$data = [
				'httpPlayer'        => ! empty( $posted->httpPlayer ) ? sanitize_key( $posted->httpPlayer ) : '',
				'proxyURL'          => ! empty( $posted->proxyURL ) ? esc_url( $posted->proxyURL ) : '',
				'volume'            => ! empty( $posted->volume ) ? intval( $posted->volume ) : '',
				'customPopupSize'   => ! empty( $posted->customPopupSize ) ? sanitize_key( $posted->customPopupSize ) : '',
				'popupWidth'        => ! empty( $posted->popupWidth ) ? intval( $posted->popupWidth ) : '',
				'popupHeight'       => ! empty( $posted->popupHeight ) ? intval( $posted->popupHeight ) : '',
				'displayAll'        => ! empty( $posted->displayAll ) ? sanitize_text_field( $posted->displayAll ) : '',
				'stickyPlayerPages' => ! empty( $posted->stickyPlayerPages ) ? $posted->stickyPlayerPages : null,
			];

			update_option( 'radio_player_settings', $data );

			wp_send_json_success();
		}

		public function get_settings() {
			$settings = (array) get_option( 'radio_player_settings', [] );

			wp_send_json_success( $settings );
		}

		/**
		 * @return bool
		 */
		public function check_permission() {
			return current_user_can( 'manage_options' );
		}

		public function check_delete_permission() {
			return current_user_can( 'delete_others_posts' );
		}



		/**
		 * Update player data
		 *
		 * @param $request
		 */
		public function set_player_data( $request ) {
			$data = json_decode( $request->get_body() );

			$post_id = ! empty( $data->postID ) ? intval( $data->postID ) : '';
			$title   = ! empty( $data->title ) ? sanitize_text_field( $data->title ) : '';

			$values = [
				'skin'           => ! empty( $data->skin ) ? sanitize_key( $data->skin ) : 'skin1',
				'stations'       => ! empty( $data->stations ) ? wp_unslash( $data->stations ) : '',
				'popup_icon'     => ! empty( $data->popup_icon ) ? sanitize_key( $data->popup_icon ) : 'off',
				'playlist_icon'  => ! empty( $data->playlist_icon ) ? sanitize_key( $data->playlist_icon ) : 'off',
				'autoplay'       => ! empty( $data->autoplay ) ? sanitize_key( $data->autoplay ) : 'off',
				'volume_control' => ! empty( $data->volume_control ) ? sanitize_key( $data->volume_control ) : 'off',
				'player_status'  => ! empty( $data->player_status ) ? sanitize_key( $data->player_status ) : 'off',
				'width'          => ! empty( $data->width ) ? intval( $data->width ) : '',
				'height'         => ! empty( $data->height ) ? intval( $data->height ) : '',
				'border_radius'  => ! empty( $data->border_radius ) ? intval( $data->border_radius ) : '',
				'bg_color'       => ! empty( $data->bg_color ) ? sanitize_text_field( $data->bg_color ) : '',
				'bg_type'        => ! empty( $data->bg_type ) ? sanitize_text_field( $data->bg_type ) : 'color',
				'bg_image'       => ! empty( $data->bg_image ) ? sanitize_text_field( $data->bg_image ) : '',
				'text_color'     => ! empty( $data->text_color ) ? sanitize_text_field( $data->text_color ) : '',
				'btn_color'      => ! empty( $data->btn_color ) ? sanitize_text_field( $data->btn_color ) : '',
				'primary_color'  => ! empty( $data->primary_color ) ? sanitize_text_field( $data->primary_color ) : '',
			];

			foreach ( $values as $key => $value ) {
				update_post_meta( $post_id, $key, $value );
			}

			if ( ! empty( $data->sticky_player ) && 'on' == $data->sticky_player ) {
				update_option( 'radio_player_sticky', $post_id );
			} else {
				$sticky_id = get_option( 'radio_player_sticky' );

				if ( $sticky_id == $post_id ) {
					delete_option( 'radio_player_sticky' );
				}
			}

			wp_update_post( [
				'ID'          => $post_id,
				'post_title'  => $title,
				'post_status' => 'publish'
			] );

			wp_send_json_success();
		}

		/**
		 * Get player data
		 *
		 * @param $data
		 */
		public function get_player_data( $data ) {
			$id = isset( $data['id'] ) ? $data['id'] : '';

			$meta = [
				'skin'           => radio_player_get_meta( $id, 'skin', 'skin1' ),
				'stations'       => radio_player_get_meta( $id, 'stations' ),
				'popup_icon'     => radio_player_get_meta( $id, 'popup_icon' ),
				'playlist_icon'  => radio_player_get_meta( $id, 'playlist_icon' ),
				'autoplay'       => radio_player_get_meta( $id, 'autoplay' ),
				'volume_control' => radio_player_get_meta( $id, 'volume_control' ),
				'player_status'  => radio_player_get_meta( $id, 'player_status' ),
				'width'          => radio_player_get_meta( $id, 'width' ),
				'height'         => radio_player_get_meta( $id, 'height' ),
				'border_radius'  => radio_player_get_meta( $id, 'border_radius' ),
				'bg_color'       => radio_player_get_meta( $id, 'bg_color' ),
				'bg_image'       => radio_player_get_meta( $id, 'bg_image' ),
				'bg_type'        => radio_player_get_meta( $id, 'bg_type' ),
				'text_color'     => radio_player_get_meta( $id, 'text_color' ),
				'btn_color'      => radio_player_get_meta( $id, 'btn_color' ),
				'primary_color'  => radio_player_get_meta( $id, 'primary_color' ),
			];

			if ( $id == get_option( 'radio_player_sticky' ) ) {
				$meta['sticky_player'] = 'on';
			}

			wp_send_json_success( $meta );
		}

		/**
		 * Get the rest api station preview
		 *
		 * @param $data
		 *
		 * @since 1.0.0
		 */

		public function get_player( $data ) {
			$id = isset( $data['id'] ) ? $data['id'] : '';

			wp_send_json_success( do_shortcode( '[radio_player id="' . $id . '" player_type="shortcode"]' ) );
		}

		/**
		 * Get all players callback
		 *
		 * @since 1.0.0
		 */
		public function get_all_player() {
			$capability = 'edit_others_posts';
			if ( ! current_user_can( $capability ) ) {
				wp_send_json_error( array(
					'message' => __( 'You do not have access to this resource.', 'radio-player' )
				), 401 );
			}

			wp_send_json_success( get_players_array() );
		}

		/**
		 * @return Radio_Player_Rest_Api_Controller|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}

}