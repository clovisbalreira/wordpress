<?php

$pages = get_pages();

$pages = ! empty( $pages ) ? wp_list_pluck( $pages, 'post_title', 'ID' ) : [];

?>

<div class="wrap radio-player-get-started">

    <div class="get-started-header">
        <img src="<?php echo RADIO_PLAYER_ASSETS . '/images/play.svg' ?>"/>
        <h2><?php _e( 'Radio Player Settings', 'radio-player' ); ?></h2>
    </div>

    <div id="radio_player_settings_app" data-pages='<?php echo str_replace( "'", '', json_encode( $pages ) ); ?>'>
        <div class="preload-wrap">
            <svg xmlns="http://www.w3.org/2000/svg">
                <circle fill="#E74C3C" stroke="none" cx="6" cy="50" r="6">
                    <animate attributeName="opacity" dur="1s" values="0;1;0" repeatCount="indefinite"
                             begin="0.1"></animate>
                </circle>
                <circle fill="#E74C3C" stroke="none" cx="26" cy="50" r="6">
                    <animate attributeName="opacity" dur="1s" values="0;1;0" repeatCount="indefinite"
                             begin="0.2"></animate>
                </circle>
                <circle fill="#E74C3C" stroke="none" cx="46" cy="50" r="6">
                    <animate attributeName="opacity" dur="1s" values="0;1;0" repeatCount="indefinite"
                             begin="0.3"></animate>
                </circle>
            </svg>
        </div>
    </div>
</div>