    <div class="radio-player-card">

        <div class="card-header">
            <img src="<?php 
echo  RADIO_PLAYER_ASSETS . '/images/play.svg' ;
?>"/>
            <h3>
                Radio Player PRO
                <p>Unlock the PRO features</p></h3>
        </div>

        <div class="card-body">
            <ul class="features">
                <li><span class="dashicons dashicons-saved"></span>Full-width sticky player.</li>
                <li><span class="dashicons dashicons-saved"></span>Display sticky player in specific pages.</li>
                <li><span class="dashicons dashicons-saved"></span>Multiple radio stations in a single player.</li>
                <li><span class="dashicons dashicons-saved"></span>Radio stations playlist.</li>
                <li><span class="dashicons dashicons-saved"></span>All player skins.</li>
                <li><span class="dashicons dashicons-saved"></span>HTTP radio stream player.</li>
                <li><span class="dashicons dashicons-saved"></span>Popup player.</li>
                <li><span class="dashicons dashicons-saved"></span>Custom popup player size.</li>
                <li><span class="dashicons dashicons-saved"></span>Radio player statistics.</li>
            </ul>
        </div>

        <div class="card-footer">
            <a href="<?php 
echo  rp_fs()->get_upgrade_url() ;
?>">Upgrade Now</a>
        </div>

    </div>
<?php 
?>

<?php 

if ( !defined( 'WP_RADIO_VERSION' ) ) {
    ?>
    <div class="radio-player-card">

        <div class="card-header">
            <img src="https://ps.w.org/wp-radio/assets/icon-256x256.png?rev=2113127" alt="WP Radio">

            <h3>WP Radio
                <p>Worldwide radio directory.</p>
            </h3>
        </div>

        <div class="card-body">
            <p>
                WP Radio is a worldwide radio station directory plugin for WordPress to play 52000+ online radio
                stations
                from all the countries over the world.
            </p>
        </div>

        <div class="card-footer">
            <a href="<?php 
    echo  admin_url( 'plugin-install.php?tab=plugin-information&plugin=wp-radio' ) ;
    ?>"
               target="_blank">Install Now</a>
            <a href="https://wordpress.org/plugins/wp-radio" target="_blank">More Details</a>
        </div>

    </div>
<?php 
}

?>

<?php 
?>

<div class="radio-player-card">

    <div class="card-header">
        <img style="border-radius: 0" src="<?php 
echo  RADIO_PLAYER_ASSETS . '/images/star.svg' ;
?>"/>
        <h3>Rate us
            <p>Please, help us to grow.</p>
        </h3>
    </div>

    <div class="card-body">
        <p>
            Hi there, it seems like <strong>Radio Player</strong> is bringing you some value, and that is pretty
            awesome! Can you please show us some love and rate Radio Player on WordPress?
            <br> <br> It will take two minutes of your time, and will really help us spread the world.
        </p>
    </div>

    <div class="card-footer">
        <a href="https://wordpress.org/support/plugin/radio-player/reviews/?filter=5#new-post" target="_blank">Rate
            us</a>
    </div>

</div>
