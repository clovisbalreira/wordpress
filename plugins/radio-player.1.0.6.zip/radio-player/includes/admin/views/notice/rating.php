<div class="notice-text">
    <img src="<?php echo RADIO_PLAYER_ASSETS . '/images/play.svg' ?>" alt="Player Radio">
    <p>
        Hi there, it seems like <strong>Radio Player</strong> is bringing you some value, and that is pretty awesome! Can you please show us some love and rate Radio Player on WordPress?
        <br> It will take two minutes of your time, and will really help us spread the world.
    </p>
</div>

<div class="notice-actions">
    <a class="hide_notice button-primary" data-value="hide_notice" href="https://wordpress.org/support/plugin/radio-player/reviews/?filter=5#new-post" target="_blank"><?php _e( 'I\'d love to help :)',
			'radio-player' ); ?></a>
    <a href="#" class="remind_later button-link-delete"><?php _e( 'Not this time', 'radio-player' ); ?></a>
    <a href="#" class="hide_notice" data-value="hide_notice"><?php _e( 'I\'ve already rated you', 'radio-player' ); ?></a>
</div>

<div class="notice-overlay-wrap">
    <div class="notice-overlay">
        <h4><?php _e( 'Would you like us to remind you about this later?', 'radio-player' ); ?></h4>

        <div class="notice-overlay-actions">
            <a href="#" data-value="3"><?php _e( 'Remind me in 3 days', 'radio-player' ); ?></a>
            <a href="#" data-value="10"><?php _e( 'Remind me in 10 days', 'radio-player' ); ?></a>
            <a href="#" data-value="hide_notice"><?php _e( 'Don\'t remind me about this', 'radio-player' ); ?></a>
        </div>

        <button type="button" class="close-notice">&times;</button>
    </div>
</div>
