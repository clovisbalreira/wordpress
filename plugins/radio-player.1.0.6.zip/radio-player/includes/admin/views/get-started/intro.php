<h3 class="tab-content-title"><?php esc_html_e( 'Introduction', 'radio-player' ) ?></h3>

<div class="tab-content-section">
    <p><?php esc_html_e( 'Radio player is a simple, easy to use, user friendly and fully customizable web radio player for WordPress.', 'radio-player' ); ?></p>
    <p><?php esc_html_e( 'You can play any live mp3, iceCast and Shoutcast stream in your WordPress website using shortcode, gutenberg block, elementor widget, sidebar widget, full-width sticky & popup player.', 'radio-player' ); ?></p>

</div>

<div class="tab-content-section">
    <h3 class="tab-content-section-title"><?php esc_html_e( 'Video Overview:', 'radio-player' ); ?></h3>

    <div class="tab-content-video">
		<?php echo do_shortcode( '[video src="https://youtu.be/05AHvgrmsTc"]' ); ?>
    </div>
</div>

<div class="tab-content-section">
    <h3 class="tab-content-section-title"><?php esc_html_e( 'Radio Player Features:', 'radio-player' ); ?></h3>

    <ul class="addon-features">
        <li>☑ <b><?php esc_html_e( 'Multiple Radio Stations', 'radio-player' ); ?></b> -
            You can add multiple radio stations to the player. Users can play them using the next/ previous buttons.
        </li>

        <li>☑ <b><?php esc_html_e( 'Full-width Sticky Player', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Full-width sticky player is available to play a radio station in all page.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Popup Player', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Popup radio player is available to play the radio in a new popup window for a better listening experience for the user.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'M3U8 stream link supports', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'You can play the live .m3u8 streams using the radio player.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Current Song Title', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Radio player can grap and play the current playing song title.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Continuous Playing', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Automatically starts playing after every page reload.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Add Unlimited Players', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'You can add unlimited radio players as you want.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Color Customizations', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Color customizations available for customizing the radio player.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Shortcode Player', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Display and play the radio player anywhere using the `[radio_player]` shortcode.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Sidebar Player Widget', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Display and play the radio player in any sidebar using the radio player widget.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Gutenberg Block', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Display and play the radio player in any page/ post using the radio player gutenberg block.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Elementor Widget', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'Display and play the radio player in any page/ post using the radio player elementor widget.', 'radio-player' ); ?>
        </li>
    </ul>
</div>
