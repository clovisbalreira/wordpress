<h3 class="tab-content-title"><?php esc_html_e( 'FAQ - Frequently Asked Questions', 'radio-player' ) ?> </h3>

<div class="tab-content-section">
    <h4 class="tab-content-section-title"><?php esc_html_e( 'How Can I add Multiple Radio Stations?', 'radio-player' ); ?>
        <i class="dashicons dashicons-plus-alt"></i></h4>
    <p><?php esc_html_e( 'You can add multiple radio stations for a single player in the PRO version. Users can play them by using the next/ previous buttons', 'radio-player' ); ?></p>
</div>

<div class="tab-content-section">
    <h4 class="tab-content-section-title"><?php esc_html_e( 'When I clicked play, there is no sound?', 'radio-player' ); ?>
        <i class="dashicons dashicons-plus-alt"></i></h4>
    <p><?php esc_html_e( 'Modern browsers no longer accepts mixed requests.', 'radio-player' ); ?>
		<?php esc_html_e( 'Please check this link:', 'radio-player' ); ?>
        <a href="https://web.dev/what-is-mixed-content">https://web.dev/what-is-mixed-content</a>.
		<?php esc_html_e( 'In case you have a HTTPS website you’ll need to use a HTTPS radio link.', 'radio-player' ); ?>

        <br>
        <br>
        But you can play the HTTP stream url in the PRO version of this plugin. Radio Player PRO has a proxy system to play the HTTP radio url stream.
        <br>
        <br>
        You need to turn on the HTTP Player settings from the settings page.
        <br>
        <br>
        <img src="<?php echo RADIO_PLAYER_ASSETS.'/images/get-started/http-player.png' ?>" alt="enable-http-player">
        <span class="img-caption">Enable HTTP Player</span>
    </p>
    
</div>

<div class="tab-content-section">
    <h4 class="tab-content-section-title"><?php esc_html_e( 'How can I us the footer full-width sticky player?', 'radio-player' ); ?>
        <i class="dashicons dashicons-plus-alt"></i></h4>
    <p>
        <?php esc_html_e( 'To set the radio player fixed to the footer as a full-width sticky player, you need to check the use as sticky player checkbox in player editing screen.', 'radio-player' ); ?>
        <br>
        <br>
        <img src="<?php echo RADIO_PLAYER_ASSETS.'/images/get-started/sticky-player.png' ?>" alt="enable-http-player">
        <span class="img-caption">Display the player as a full-width sticky player at the bottom of the site</span>
    </p>
</div>



<div class="tab-content-section">
    <h4 class="tab-content-section-title"><?php esc_html_e( 'Can I use multiple radio players in a single page?', 'radio-player' ); ?>
        <i class="dashicons dashicons-plus-alt"></i></h4>
    <p><?php esc_html_e( 'Yes, you can display and play multiple radio players in a single page.', 'radio-player' ); ?></p>
</div>


