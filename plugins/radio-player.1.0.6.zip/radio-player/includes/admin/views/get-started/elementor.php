<h3 class="tab-content-title"><?php esc_html_e('Elementor Widgets', 'radio-player'); ?></h3>

<div class="tab-content-section">
    <p><?php esc_html_e('The plugin provides an elementor widget for displaying the radio player in any page/ post.', 'radio-player'); ?></p>

    <p><?php esc_html_e('While you are on the post/page elementor edit screen, Add the Radio Player widget from basic category.', 'radio-player'); ?></p>

    <img src="<?php echo RADIO_PLAYER_ASSETS . '/images/elementor-widget.png' ?>" alt="<?php esc_attr_e('Add Radio Player Elementor Widget', 'radio-player'); ?>">
    <span class="img-caption"><?php esc_html_e('Radio player elementor widget', 'radio-player'); ?></span>


</div>

<div class="tab-content-section">
    <p><?php esc_html_e('After selecting the Radio Player widget, you need to select the radio player that you want to display.', 'radio-player'); ?></p>

    <img src="<?php echo RADIO_PLAYER_ASSETS . '/images/add-elementor-widget.png' ?>" alt="<?php esc_attr_e('Radio Player Elementor Widget', 'radio-player'); ?>">
    <span class="img-caption"><?php _e('Add elementor radio player widget', 'radio-player'); ?></span>

</div>
