<h3 class="tab-content-title"><?php esc_html_e( 'Sidebar Widgets', 'radio-player' ); ?></h3>

<p><?php esc_html_e( 'The plugin provides a sidebar widget for displaying the radio player.', 'radio-player' ); ?></p>

<div class="tab-content-section">

    <h4 class="tab-content-section-title"><?php esc_html_e( 'Display the radio player in a sidebar by widget.', 'radio-player' ); ?></h4>

    <p><?php esc_html_e( 'For displaying the radio player by the widget, you have to navigate to Appearance > Widgets.
        Then select the Radio Player widget and drag to the sidebar where you want to display the radio player.', 'radio-player' ); ?></p>

    <img src="<?php echo RADIO_PLAYER_ASSETS . '/images/radio-player-widget.png' ?>"
         alt="<?php esc_html_e( 'Add Radio Player Widget', 'radio-player' ); ?>">
    <span class="img-caption"><?php esc_html_e( 'Radio player sidebar widget', 'radio-player' ); ?></span>


    <p><?php esc_html_e( 'After selecting the radio player, you have to enter the widget title and select the radio player that will be played by the player.', 'radio-player' ); ?></p>


</div>


