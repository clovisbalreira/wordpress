<h2 class="tab-content-title"><?php _e( 'See what\'s new in the last updates.', 'radio-player' ); ?></h2>

<!--v1.0.6-->
<div class="log-wrap">
    <h4 class="description"><span>v1.0.6 (15 October, 2021)</span> <i class="dashicons dashicons-minus"></i></h4>
    <ul class="logs">
        <li class="log"><span class="badge"><?php _e( 'New features.', 'radio-player' ); ?></span></li>
        <li class="log"><i class="dashicons dashicons-plus-alt"></i> Add play count column to the player list table</li>

        <li class="log"><span class="badge">Enhancements</span></li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Fixed WordPress compatibility check</li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Fixed current track title display</li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Fixed HTTP stream player</li>
    </ul>
</div>


<!--v1.0.5-->
<div class="log-wrap">
    <h4 class="description"><span>v1.0.5 (14 October, 2021)</span> <i class="dashicons dashicons-plus-alt"></i></h4>
    <ul class="logs">
        <li class="log"><span class="badge"><?php _e( 'New features.', 'radio-player' ); ?></span></li>
        <li class="log"><i class="dashicons dashicons-plus-alt"></i> Add 2 new player skins</li>
        <li class="log"><i class="dashicons dashicons-plus-alt"></i> Add track artist display</li>
        <li class="log"><i class="dashicons dashicons-plus-alt"></i> Player background image support</li>

        <li class="log"><span class="badge">Enhancements</span></li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Fixed .m3u8 stream player</li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Fixed admin dashboard responsive design</li>
    </ul>
</div>

<!--v1.0.4-->
<div class="log-wrap">
    <h4 class="description"><span>v1.0.4 (07 September, 2021)</span> <i class="dashicons dashicons-plus-alt"></i></h4>
    <ul class="logs">
        <li class="log"><span class="badge"><?php _e( 'New features.', 'radio-player' ); ?></span></li>
        <li class="log"><i class="dashicons dashicons-plus-alt"></i> Added sticky player display page selection</li>
        <li class="log"><i class="dashicons dashicons-plus-alt"></i> Radio player statistics dashboard widget and page
        </li>

        <li class="log"><span class="badge">Enhancements</span></li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Fixed .m3u8 stream player</li>
    </ul>
</div>


<div class="log-wrap">
    <h4 class="description"><span>v1.0.3 (26 August, 2021)</span> <i class="dashicons dashicons-plus-alt"></i></h4>
    <ul class="logs">
        <li class="log"><span class="badge"><?php _e( 'New features.', 'radio-player' ); ?></span></li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i> Add station playlist
        </li>

        <li class="log"><span class="badge">Enhancements</span></li>
        <li class="log">
            <i class="dashicons dashicons-update-alt"></i> Fixed showing current station metadata title
        </li>
        <li class="log">
            <i class="dashicons dashicons-update-alt"></i> Fixed HTTP stream URL player
        </li>
    </ul>
</div>

<div class="log-wrap">
    <h4 class="description"><span>v1.0.2 (15 August, 2021)</span> <i class="dashicons dashicons-plus-alt"></i></h4>
    <ul class="logs">
        <li class="log"><span class="badge"><?php _e( 'New features.', 'radio-player' ); ?></span></li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i> Added radio player duplicator
        </li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i> Added multiple radio stations supports for the player
        </li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i> Added next/ previous buttons on the radio player
        </li>


        <li class="log"><span class="badge">Enhancements</span></li>
        <li class="log">
            <i class="dashicons dashicons-update-alt"></i> Fixed WordPress core screen options and help not working
            issue
        </li>
        <li class="log">
            <i class="dashicons dashicons-update-alt"></i> Fixed rado player sync issue
        </li>

    </ul>
</div>


<div class="log-wrap">
    <h4 class="description"><span>v1.0.1 (10 July, 2021)</span> <i class="dashicons dashicons-plus-alt"></i></h4>
    <ul class="logs">
        <li class="log"><span class="badge"><?php _e( 'New features.', 'radio-player' ); ?></span></li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i>
            Added HTTP stream player
        </li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i>
            Added settings page
        </li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i>
            Added default player volume settings
        </li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i>
            Added popup player size settings
        </li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i>
            Added real-time player preview while editing
        </li>
        <li class="log">
            <i class="dashicons dashicons-plus-alt"></i>
            Added multiple player skins
        </li>


        <li class="log"><span class="badge">Enhancements</span></li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Updated the radio player to react js for better
            user experience
        </li>
        <li class="log"><i class="dashicons dashicons-update-alt"></i> Improved the whole plugin UI design</li>


    </ul>
</div>

