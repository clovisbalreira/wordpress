<h3 class="tab-content-title"><?php esc_html_e( 'Add New Player', 'radio-player' ) ?></h3>

<div class="tab-content-section">


    <p><?php esc_html_e( 'After installing and activating the plugin successfully, The next step is to add new players. You can add unlimited new players very easily.', 'radio-player' ); ?></p>
    <p><?php esc_html_e( 'For adding a new players you have to navigate to the Add New Player submenu under the Radio Player main menu.', 'radio-player' ); ?></p>
    <p><?php esc_html_e( 'You would find the below options in the add new radio player page:', 'radio-player' ); ?></p>

    <ul class="addon-features">
        <li>☑ <b><?php esc_html_e( 'Title', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The name of the player.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Stations', 'radio-player' ); ?></b> - The radio stations that will be played by the player.
            You can add multiple radio station in the PRO version. You have to add the radio stations with the belo
            fields:
            <ol>
                <li><b>Station Title</b> - The title of the radio station.</li>
                <li><b>Stream URL</b> - The radio station live stream URL that will be played.</li>
                <li><b>Thumbnail</b> - The station logo image.</li>
            </ol>

        </li>
        <li>☑ <b><?php esc_html_e( 'Popup Icon', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The popup player opener icon. You can show/ hide the popup player icon in the player.', 'radio-player' ); ?>
        </li>


        <li>☑ <b><?php esc_html_e( 'Playlist Icon', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'You can show/ hide the radio station playlist icon in the player.', 'radio-player' ); ?>
        </li>


        <li>☑ <b><?php esc_html_e( 'Autoplay', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'You can control the autoplay settings of the radio player.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Volume Control', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The volume control button. You can show/hide the volume control button.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Player Status', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The live/ offline indicator status for the player. You can show/hide the player status in the player.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Player Width', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The radio player width. You can customize the with of the radio player.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Border Radius', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The player rounded border-radius. You can customize this option too.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Primary Color', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The player primary color.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Background Color', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The player background color.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Text Color', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The player text color.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Button Color', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'The player button color.', 'radio-player' ); ?></li>
        <li>☑ <b><?php esc_html_e( 'Use as Sticky Player', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'If this option is ON the player will be displayed as a full-width sticky player at the footer of every page.', 'radio-player' ); ?>
        </li>
        <li>☑ <b><?php esc_html_e( 'Preview', 'radio-player' ); ?></b>
            - <?php esc_html_e( 'You can preview the radio player while you are adding it.', 'radio-player' ); ?></li>
    </ul>

    <br>
    <br>
    <img src="<?php echo RADIO_PLAYER_ASSETS . '/images/get-started/add-new-radio-player.png' ?>"
         alt="add-new-radio-player">
    <span class="img-caption">Add new radio player screen</span>

</div>


