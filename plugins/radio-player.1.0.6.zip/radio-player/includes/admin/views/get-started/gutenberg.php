<h3 class="tab-content-title"><?php esc_html_e( 'Gutenberg Blocks', 'radio-player' ); ?></h3>

<div class="tab-content-section">
    <p><?php esc_html_e( 'The plugin provide a gutenberg block for displaying the radio player in any page/ post.', 'radio-player' ); ?></p>

    <p>
		<?php esc_html_e( 'While you are on the post/page edit screen,  click the gutenberg plus icon to add a new gutenberg block.', 'radio-player' ); ?>
        <br>
		<?php esc_html_e( 'Add Radio Player block from Media block category.', 'radio-player' ); ?>
    </p>
    <p>
		<?php esc_html_e( 'After selecting the Radio Player block, you need to enter the station id of the radio station.', 'radio-player' ); ?>
        <br>
		<?php esc_html_e( 'You can change the radio player by clicking the change player option at the top toolbar.', 'radio-player' ); ?>
    </p>
    <img src="<?php echo esc_url(RADIO_PLAYER_ASSETS . '/images/gutenberg-block.png'); ?>"
         alt="<?php esc_attr_e( 'Radio Player Block', 'radio-player' ); ?>">
    <span class="img-caption"><?php esc_html_e( 'Add radio player block', 'radio-player' ); ?></span>

</div>
