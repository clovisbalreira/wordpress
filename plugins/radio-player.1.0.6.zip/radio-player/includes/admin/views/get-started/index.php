<div class="wrap radio-player-get-started">

    <div class="get-started-header">
        <img src="<?php echo RADIO_PLAYER_ASSETS . '/images/play.svg' ?>"/>
        <h2><?php _e( 'Radio Player  - Live Shoutcast, Icecast and Audio Stream Player for Wordpress', 'radio-player' ); ?></h2>
    </div>

    <div class="tab-wrap">

        <div class="tab-links">

            <a href="#" data-target="setup" class="tab-link active">
                <i class="dashicons dashicons-info"></i>
				<?php esc_html_e( 'Introduction', 'radio-player' ); ?></a>

            <a href="javascript:;" data-target="new" class="tab-link">
                <i class="dashicons dashicons-info-outline"></i>
		        <?php _e( 'What\'s New?', 'radio-player' ); ?>
            </a>

            <a href="#" data-target="add-new" class="tab-link">
                <i class="dashicons dashicons-media-audio"></i>
				<?php esc_html_e( 'Add New Player', 'radio-player' ); ?></a>

            <a href="#" data-target="usage" class="tab-link">
                <i class="dashicons dashicons-media-code"></i>
				<?php esc_html_e( 'Usage', 'radio-player' ); ?></a>

            <a href="#" data-target="shortcodes" class="tab-link">
                <i class="dashicons dashicons-shortcode"></i>
				<?php esc_html_e( 'Shortcodes', 'radio-player' ); ?></a>

            <a href="#" data-target="gutenberg" class="tab-link">
                <i class="dashicons dashicons-insert-after"></i>
				<?php esc_html_e( 'Gutenberg Block', 'radio-player' ); ?></a>

            <a href="#" data-target="elementor" class="tab-link">
                <i class="dashicons dashicons-align-pull-left"></i>
				<?php esc_html_e( 'Elementor Widget', 'radio-player' ); ?></a>

            <a href="#" data-target="widget" class="tab-link">
                <i class="dashicons dashicons-align-wide"></i>
				<?php esc_html_e( 'Sidebar Widget', 'radio-player' ); ?></a>

            <a href="#" data-target="faq" class="tab-link">
                <i class="dashicons dashicons-editor-help"></i>
				<?php esc_html_e( 'FAQ', 'radio-player' ); ?></a>


        </div>

        <div id="setup" class="tab-content active">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/intro.php'; ?>
        </div>

        <div id="new" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/new.php'; ?>
        </div>

        <div id="add-new" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/add-new.php'; ?>
        </div>

        <div id="usage" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/usage.php'; ?>
        </div>

        <div id="gutenberg" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/gutenberg.php'; ?>
        </div>


        <div id="elementor" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/elementor.php'; ?>
        </div>

        <div id="shortcodes" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/shortcodes.php'; ?>
        </div>

        <div id="widget" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/widget.php'; ?>
        </div>

        <div id="faq" class="tab-content">
			<?php include_once RADIO_PLAYER_INCLUDES . '/admin/views/get-started/faq.php'; ?>
        </div>

    </div>

</div>