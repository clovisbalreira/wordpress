<h3 class="tab-content-title"><?php _e( 'Shortcodes', 'radio-player' ) ?></h3>

<p><?php _e( 'This plugin provides a shortcode for displaying the radio player anywhere you want:', 'radio-player' ) ?></p>


<div class="tab-content-section">
    <h4 class="tab-content-section-title"><?php esc_html_e( 'Radio player shortcode', 'radio-player' ); ?> - <code>[radio_player]</code></h4>

    <p><code>[radio_player]</code>
        – <?php esc_html_e( 'For displaying the radio player use [radio_player] shortcode.','radio-player' ); ?>
    </p>

    <p><?php esc_html_e( 'This shortcode supports a required id attribute where you have to pass the id of the radio player
        that you want to display.', 'radio-player' ); ?></p>

    <p><b><?php esc_html_e( 'Example:', 'radio-player' ); ?></b> <code>[radio_player id="11"]</code></p>

    <br>
    <br>
    <img src="<?php echo RADIO_PLAYER_ASSETS.'/images/get-started/shortcode.png' ?>" alt="radio-player-shortcode">
    <span class="img-caption">Radio player shortcodes</span>


</div>

