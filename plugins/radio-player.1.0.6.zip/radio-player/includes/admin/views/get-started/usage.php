<h3 class="tab-content-title"><?php esc_html_e( 'Usage', 'radio-player' ) ?></h3>


<div class="tab-content-section">

	<ul class="addon-features">
		<li>☑  <?php esc_html_e( 'After you have successfully activated the plugin, Radio Player menu will appear in your WordPress dashboard sidebar menu.', 'radio-player' ); ?></li>
		<li>☑  <?php esc_html_e( 'You can add unlimited radio player from the Add New Player page.', 'radio-player' ); ?></li>
		<li>☑  <?php esc_html_e( 'You can use the [radio_player id="player_id"] shortcode, gutenberg radio player block, elementor radio player widget, native sidebar radio player widget, full-width sticky player and popup player.', 'radio-player' ); ?></li>
	</ul>

</div>