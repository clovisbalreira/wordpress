<?php

defined( 'ABSPATH' ) || exit;
if ( !class_exists( 'Radio_Player_Chart_Widget' ) ) {
    class Radio_Player_Chart_Widget
    {
        /** @var null */
        private static  $instance = null ;
        /**
         * Radio_Player_Chart_Widget constructor.
         */
        public function __construct()
        {
            add_action( 'wp_dashboard_setup', [ $this, 'dashboard_widgets' ] );
        }
        
        public function dashboard_widgets()
        {
            wp_add_dashboard_widget( 'radio_player_chart', esc_html__( 'Radio Player Stats', 'radio-player' ), [ $this, 'dashboard_widget_cb' ] );
            // Globalize the metaboxes array, this holds all the widgets for wp-admin.
            global  $wp_meta_boxes ;
            // Get the regular dashboard widgets array
            // (which already has our new widget but appended at the end).
            $default_dashboard = $wp_meta_boxes['dashboard']['normal']['core'];
            // Backup and delete our new dashboard widget from the end of the array.
            $wp_dark_mode_widget_backup = array(
                'radio_player_chart' => $default_dashboard['radio_player_chart'],
            );
            unset( $default_dashboard['radio_player_chart'] );
            // Merge the two arrays together so our widget is at the beginning.
            $sorted_dashboard = array_merge( $wp_dark_mode_widget_backup, $default_dashboard );
            // Save the sorted array back into the original metaboxes.
            $wp_meta_boxes['dashboard']['normal']['core'] = $sorted_dashboard;
        }
        
        public function dashboard_widget_cb()
        {
            if ( !class_exists( 'Radio_Player_Statistics' ) ) {
                include_once RADIO_PLAYER_INCLUDES . '/class-statistics.php';
            }
            $args = [
                'start_date' => date( 'Y-m-d', strtotime( '-7 Days' ) ),
                'end_date'   => date( 'Y-m-d', strtotime( 'tomorrow' ) ),
            ];
            $obj = Radio_Player_Statistics::instance( $args );
            ?>

            <div class="radio-player-chart">

                <div class="chart-header">
                    <span>How many times the radio players are played in each day.</span>

                    <select name="radio_player_chart_period" id="radio_player_chart_period">
                        <option value="7">Last 7 Days</option>
                        <option value="30">Last 30 Days</option>
                    </select>
                </div>

				<?php 
            $obj->chart();
            ?>
                    <div class="radio-player-dash-widget-wrapper">
                        <div class="radio-player-dash-widget">
                            <h2>View radio play stats inside WordPress Dashboard</h2>
                            <p>Upgrade to Pro and get access to the stats.</p>
                            <p>
                                <a href="<?php 
            echo  rp_fs()->get_upgrade_url() ;
            ?>" class="button button-primary">Upgrade to Pro</a>
                            </p>

                        </div>
                    </div>
				<?php 
            ?>
            </div>
		<?php 
        }
        
        /**
         * @return Radio_Player_Chart_Widget|null
         */
        public static function instance()
        {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }
    
    }
}
Radio_Player_Chart_Widget::instance();