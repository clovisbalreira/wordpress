<?php

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Radio_Player_Admin' ) ) {
	class Radio_Player_Admin {
		/** @var null */
		private static $instance = null;

		/**
		 * WP_Podcasts_Admin constructor.
		 */
		public function __construct() {
			add_action( 'admin_menu', [ $this, 'admin_menu' ], 99 );


			// Player post columns
			add_filter( 'manage_edit-radio_columns', [ $this, 'radio_post_columns' ] );
			add_filter( 'manage_radio_posts_custom_column', [ $this, 'radio_columns_data' ], 10, 2 );
			add_action( 'admin_init', [ $this, 'init_update' ] );

			add_action( 'admin_notices', [ $this, 'display_notices' ] );

		}

		public function display_notices() {

			//Rating notice if proxy notice is off
			if ( 'off' != get_option( 'wp_radio_rating_notice' ) &&
			     'off' != get_transient( 'radio_player_rating_notice_interval' ) ) {

				ob_start();
				include RADIO_PLAYER_INCLUDES . '/admin/views/notice/rating.php';
				$notice_html = ob_get_clean();
				radio_player()->add_notice( 'info  radio-player-rating-notice', $notice_html );

				return;
			}
		}

		public function init_update() {

			if ( ! class_exists( 'Radio_Player_Update' ) && current_user_can( 'manage_options' ) ) {
				include_once RADIO_PLAYER_INCLUDES . '/admin/class-update.php';

				$updater = Radio_Player_Update::instance();
				if ( $updater->needs_update() ) {
					$updater->perform_updates();
				}
			}
		}

		/**
		 * Add ID column to the radio posts table
		 *
		 * @param $columns
		 *
		 * @return array
		 *
		 * @since 1.0.0
		 */
		public function radio_post_columns( $columns ) {
			return array(
				'cb'                   => '<input type="checkbox" />',
				'id'                   => __( 'ID', 'radio-player' ),
				'title'                => __( 'Title', 'radio-player' ),
				'shortcode'            => __( 'Shortcode', 'radio-player' ),
				'play_count'           => __( 'Play Count', 'radio-player' ),
				'radio_player_preview' => __( 'Preview', 'radio-player' ),
				'date'                 => __( 'Date', 'radio-player' ),
			);
		}


		/**
		 * Display the ID column data
		 *
		 * @param $column
		 * @param $post_id
		 */
		public function radio_columns_data( $column, $post_id ) {

			if ( 'radio' == get_post_type( $post_id ) ) {
				if ( $column == 'id' ) {
					echo $post_id;
				} elseif ( $column == 'shortcode' ) {
					printf( '<input id="player_shortcode" class="shortcode" type="text" readonly value="[radio_player id=%s]" />', esc_attr( $post_id ) );
				} elseif ( $column == 'radio_player_preview' ) {
					printf( '<a href="%1$s" target="_blank" class="button-primary"><i class="dashicons dashicons-visibility"></i> %2$s</a>',
						site_url( "?radio_player=$post_id&preview" ),
						__( 'Preview', 'radio-player' )
					);
				} elseif ( $column == 'play_count' ) {
					global $wpdb;

					$sql   = $wpdb->prepare( "SELECT SUM(`count`)  FROM {$wpdb->prefix}radio_player_statistics WHERE player_id = %d;", $post_id );
					$count = $wpdb->get_var( $sql );

					printf( '<span>%s</span>', $count );
				}
			}

		}


		/**
		 * Add admin menu
		 * @since 1.0.0
		 */
		public function admin_menu() {
			add_submenu_page( 'edit.php?post_type=radio', __( 'Radio Player Get Started', 'radio-player' ), __( 'Get Started', 'radio-player' ), 'manage_options', 'radio-player-get-started', [
				$this,
				'get_started_page',
			] );

			add_submenu_page( 'edit.php?post_type=radio', __( 'Statistics', 'radio-player' ), __( 'Statistics', 'radio-player' ), 'manage_options', 'statistics', [
				$this,
				'render_statistics_page'
			] );

			add_submenu_page( 'edit.php?post_type=radio', __( 'Radio Player Settings', 'radio-player' ), __( 'Settings', 'radio-player' ), 'manage_options', 'radio-player-settings', [
				$this,
				'render_settings_page',
			] );
		}

		/**
		 * Get started page callback
		 *
		 * @since 1.0.0
		 */
		public function get_started_page() {
			include RADIO_PLAYER_INCLUDES . '/admin/views/get-started/index.php';
		}


		public function render_settings_page() {
			include RADIO_PLAYER_INCLUDES . '/admin/views/settings-page.php';
		}

		/**
		 * Statistics Page
		 */
		public function render_statistics_page() {
			include RADIO_PLAYER_INCLUDES . '/admin/views/statistics.php';
		}


		/**
		 * @return Radio_Player_Admin|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}

}

Radio_Player_Admin::instance();