<?php

/** Block direct access */
defined( 'ABSPATH' ) || exit();

/** check if class `Radio_Player_Metabox` not exists yet */
if ( ! class_exists( 'Radio_Player_Metabox' ) ) {
	/**
	 * Class Radio_Player_Metabox
	 *
	 * Handle metaboxes
	 *
	 * @package Prince\WP_Radio
	 *
	 * @since 1.0.0
	 */
	class Radio_Player_Metabox {

		/**
		 * @var null
		 */
		private static $instance = null;

		/**
		 * Radio_Player_Metabox constructor.
		 * Initialize the custom Meta Boxes for prince-options api.
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			add_action( 'add_meta_boxes', array( $this, 'register_meta_boxes' ) );
			add_action( 'do_meta_boxes', [ $this, 'remove_meta_box' ] );
		}

		public function remove_meta_box() {
			remove_meta_box( 'postimagediv', [ 'radio' ], 'side' );
			remove_meta_box( 'submitdiv', [ 'radio' ], 'side' );
		}

		/**
		 * register metaboxes
		 */
		public function register_meta_boxes() {

			// Radio player configuration
			add_meta_box( 'radio_player_metabox', __( 'Player Configuration', 'radio-player' ), [
				$this,
				'render_metabox'
			], [ 'radio' ], 'normal', 'high' );

			add_meta_box( 'radio_player_side_metabox', __( 'Get more', 'radio-player' ), [
				$this,
				'render_side_metabox'
			], [ 'radio' ], 'side', 'high' );

		}

		/**
		 * render station info metabox content
		 *
		 * @since 1.0.0
		 */
		public function render_metabox() {
			include_once RADIO_PLAYER_INCLUDES.'/admin/views/metabox.php';
		}

		public function render_side_metabox() {
			include_once RADIO_PLAYER_INCLUDES.'/admin/views/side-metabox.php';
		}


		/**
		 * @return Radio_Player_Metabox|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

	}
}

Radio_Player_Metabox::instance();
