<?php

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Radio_Player_Update' ) ) {
	class Radio_Player_Update {

		private static $instance = null;

		/**
		 * The upgrades
		 *
		 * @var array
		 */
		private static $upgrades = array( '1.0.1', '1.0.2', '1.0.4' );

		public function installed_version() {

			return get_option( 'radio_player_version' );
		}

		/**
		 * Check if the plugin needs any update
		 *
		 * @return boolean
		 */
		public function needs_update() {

			// may be it's the first install
			if ( empty( $this->installed_version() ) ) {
				return false;
			}

			//if previous version is lower
			if ( version_compare( $this->installed_version(), RADIO_PLAYER_VERSION, '<' ) ) {
				return true;
			}


			return false;
		}

		/**
		 * Perform all the necessary upgrade routines
		 *
		 * @return void
		 */
		public function perform_updates() {

			foreach ( self::$upgrades as $version ) {

				if ( version_compare( $this->installed_version(), $version, '<' ) ) {
					$file = RADIO_PLAYER_INCLUDES . "/updates/class-update-$version.php";

					if ( file_exists( $file ) ) {
						include_once $file;
					}

					update_option( 'radio_player_version', $version );
				}
			}

			delete_option( 'radio_player_version' );
			update_option( 'radio_player_version', RADIO_PLAYER_VERSION );
		}

		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

	}
}