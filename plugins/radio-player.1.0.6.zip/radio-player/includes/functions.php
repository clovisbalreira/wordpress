<?php

defined( 'ABSPATH' ) || exit();

/**
 * Get metadata
 *
 * @param $post_id
 * @param $key
 * @param string $default
 *
 * @return mixed|string
 * @since 1.0.0
 */
function radio_player_get_meta( $post_id, $key, $default = '' ) {
	$meta = get_post_meta( $post_id, $key, true );

	return ! empty( $meta ) ? $meta : $default;
}

function radio_player_get_stream_title( $streamingUrl, $interval = 19200, $offset = 0 ) {

	if ( empty( $streamingUrl ) ) {
		return false;
	}

	$needle = stristr( $streamingUrl, '.ogg' ) ? 'title=' : 'StreamTitle=';

	$ua   = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36';
	$opts = [
		'http' => [
			'method'     => 'GET',
			'header'     => 'Icy-MetaData: 1',
			'user_agent' => $ua,
		],
	];

	try {
		$headers = @get_headers( $streamingUrl );
	} catch ( Exception $exception ) {
		return $exception->getMessage();
	}

	if ( ! is_array( $headers ) ) {
		return '';
	}


	foreach ( $headers as $h ) {
		if ( strpos( strtolower( $h ), 'icy-metaint' ) !== false && ( $interval = explode( ':', $h )[1] ) ) {
			break;
		}
	}


	$context = stream_context_create( $opts );

	if ( $stream = @fopen( $streamingUrl, 'r', false, $context ) ) {

		@$buffer = stream_get_contents( $stream, (int) $interval, $offset );

		if ( strpos( $buffer, $needle ) !== false ) {
			fclose( $stream );

			$title = explode( $needle, $buffer )[1];

			return 'title=' == $needle ? substr( $title, 1, strpos( $title, 'server' ) - 5 )
				: substr( $title, 1, strpos( $title, ';' ) - 2 );
		}

	} else {
		return '';
	}
}

/**
 * Get all player ids
 *
 * @return array
 * @since 1.0.0
 */
function radio_player_get_player_ids() {
	$players = get_posts( [
		'post_type'   => 'radio',
		'numberposts' => - 1,
		'post_status' => 'publish'
	] );

	return wp_list_pluck( $players, 'ID' );

}

/**
 * Get all players ids
 *
 * @return array
 * @since 1.0.0
 */
function get_players_array() {
	$players = [];

	if ( ! empty( radio_player_get_player_ids() ) ) {
		foreach ( radio_player_get_player_ids() as $id ) {
			$players[ $id ] = get_the_title( $id );
		}
	}

	return $players;
}

function radio_player_escape_quote( $string ) {
	return str_replace( "'", '', $string );
}

function radio_player_get_setting( $key, $default = '' ) {
	$settings = (array) get_option( 'radio_player_settings' );

	return ! empty( $settings[ $key ] ) ? $settings[ $key ] : $default;
}

function radio_player_get_user_ip() {
	if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
		//ip from share internet
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
		//ip pass from proxy
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}

	return $ip;
}


