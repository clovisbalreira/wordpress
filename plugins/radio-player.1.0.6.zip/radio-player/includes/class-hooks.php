<?php

defined( 'ABSPATH' ) || exit;
if ( !class_exists( 'Radio_Player_Hooks' ) ) {
    class Radio_Player_Hooks
    {
        /** @var null */
        private static  $instance = null ;
        /**
         * Radio_Player_Hooks constructor.
         */
        public function __construct()
        {
            //render the footer sticky player
            add_action( 'wp_footer', [ $this, 'render_player' ] );
            //popup player
            add_action( 'template_redirect', [ $this, 'popup_player' ] );
            //update stream title
            add_action( 'wp_ajax_radio_player_update_stream_title', array( $this, 'update_stream_title' ) );
            add_action( 'wp_ajax_nopriv_radio_player_update_stream_title', array( $this, 'update_stream_title' ) );
        }
        
        public function update_stream_title()
        {
            $id = ( !empty($_REQUEST['id']) ? intval( $_REQUEST['id'] ) : '' );
            $index = ( !empty($_REQUEST['index']) ? intval( $_REQUEST['index'] ) : 0 );
            $stations = radio_player_get_meta( $id, 'stations' );
            if ( empty($stations) ) {
                wp_send_json_error( __( 'No stations', 'radio-player' ) );
            }
            $url = $stations[$index]->stream;
            $title = '';
            //get stream info
            
            if ( preg_match( '/(?<server>^https?:\\/\\/.*:\\d+\\/)/', $url, $match ) ) {
                $server = $match['server'] . 'stats?sid=1&json=1';
                $response = wp_remote_get( $server );
                
                if ( !is_wp_error( $response ) ) {
                    $json = wp_remote_retrieve_body( $response );
                    $meta = json_decode( $json );
                    if ( !empty($meta) ) {
                        if ( !empty($meta->songtitle) ) {
                            $title = $meta->songtitle;
                        }
                    }
                }
            
            }
            
            
            if ( empty($title) ) {
                $stream_title = radio_player_get_stream_title( $url );
                if ( !is_wp_error( $stream_title ) && !empty($stream_title) ) {
                    $title = $stream_title;
                }
            }
            
            wp_send_json_success( $title );
        }
        
        /**
         * Render footer sticky player
         *
         * @since 1.0.0
         */
        public function render_player()
        {
            return;
            $displayAll = radio_player_get_setting( 'displayAll', 'on' );
            
            if ( 'on' != $displayAll ) {
                $stickyPlayerPages = radio_player_get_setting( 'stickyPlayerPages', [] );
                $pages = wp_list_pluck( $stickyPlayerPages, 'value' );
                global  $post ;
                if ( !$post || !in_array( $post->ID, $pages ) ) {
                    return;
                }
            }
            
            $sticky_player = get_option( 'radio_player_sticky' );
            if ( !get_post( $sticky_player ) ) {
                return;
            }
            if ( $sticky_player ) {
                echo  do_shortcode( '[radio_player id="' . $sticky_player . '" player_type="full-width" ]' ) ;
            }
        }
        
        /**
         * Render the popup player
         *
         * @since 1.0.0
         */
        public function popup_player()
        {
            
            if ( !empty($_GET['radio_player']) ) {
                $player_id = intval( $_GET['radio_player'] );
                query_posts( [
                    'p'         => $player_id,
                    'post_type' => get_post_type( $player_id ),
                ] );
                add_filter( 'show_admin_bar', '__return_false' );
                // Remove all WordPress actions
                remove_all_actions( 'wp_head' );
                remove_all_actions( 'wp_print_styles' );
                remove_all_actions( 'wp_print_head_scripts' );
                remove_all_actions( 'wp_footer' );
                // Handle `wp_head`
                add_action( 'wp_head', 'wp_enqueue_scripts', 1 );
                add_action( 'wp_head', 'wp_print_styles', 8 );
                add_action( 'wp_head', 'wp_print_head_scripts', 9 );
                add_action( 'wp_head', 'wp_site_icon' );
                // Handle `wp_footer`
                add_action( 'wp_footer', 'wp_print_footer_scripts', 20 );
                add_action( 'wp_footer', 'wp_auth_check_html', 30 );
                // Handle `wp_enqueue_scripts`
                remove_all_actions( 'wp_enqueue_scripts' );
                // Also remove all scripts hooked into after_wp_tiny_mce.
                remove_all_actions( 'after_wp_tiny_mce' );
                add_action( 'wp_enqueue_scripts', [ 'Radio_Player_Enqueue', 'frontend_scripts' ], 999999 );
                ?>

                <!doctype html>
                <html lang="<?php 
                language_attributes();
                ?>">
                <head>
                    <meta charset="<?php 
                bloginfo( 'charset' );
                ?>">
                    <meta name="viewport"
                          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
                    <meta http-equiv="X-UA-Compatible" content="ie=edge">
                    <title><?php 
                wp_title( '' );
                ?></title>

					<?php 
                do_action( 'wp_head' );
                ?>

                </head>
                <body>

				<?php 
                echo  do_shortcode( '[radio_player id="' . $player_id . '" player_type="popup" ]' ) ;
                ?>


				<?php 
                do_action( 'wp_footer' );
                ?>

                </body>
                </html>

				<?php 
                exit;
            }
        
        }
        
        /**
         * @return Radio_Player_Hooks|null
         */
        public static function instance()
        {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }
    
    }
}
Radio_Player_Hooks::instance();