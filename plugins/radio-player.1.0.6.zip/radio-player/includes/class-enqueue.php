<?php

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Radio_Player_Enqueue' ) ) {
	class Radio_Player_Enqueue {

		/**
		 * @var null
		 */
		private static $instance = null;

		/**
		 * Radio_Player_Enqueue constructor.
		 */
		public function __construct() {
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ] );
			add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue' ] );
			add_action( 'elementor/frontend/before_enqueue_scripts', [ $this, 'elementor_scripts' ] );
		}


		/**
		 * Frontend Scripts
		 *
		 * @param $hook
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public static function frontend_scripts() {

			wp_enqueue_style( 'radio-player', RADIO_PLAYER_ASSETS . '/css/frontend.css', [] );

			/* enqueue frontend script */
			wp_enqueue_script( 'radio-player', RADIO_PLAYER_ASSETS . '/js/frontend.min.js', array(
				'wp-element',
				'wp-util',
				'wp-api-fetch',
			), RADIO_PLAYER_VERSION, true );


			/* localized script attached to 'wp-radio' */
			wp_localize_script( 'radio-player', 'radioPlayer', array(
				'plugin_url'      => RADIO_PLAYER_URL,
				'admin_url'       => admin_url(),
				'ajax_url'        => admin_url( 'admin-ajax.php' ),
				'site_url'        => site_url(),
				'is_popup_player' => ! empty( $_GET['radio_player'] ),
				'isPreview'       => isset( $_GET['preview'] ),
				'popup_url'       => str_replace( 'https', 'http', site_url() ),
				'nonce'           => wp_create_nonce( 'radio-player' ),
				'i18n'            => array(),
				'isPro'           => rp_fs()->can_use_premium_code__premium_only(),
				'settings'        => (array) get_option( 'radio_player_settings' ),
				'isHTTP'          => empty( $_SERVER['HTTPS'] ) || 'off' == $_SERVER['HTTPS'],
				'userIP'          => radio_player_get_user_ip(),
			) );


		}

		/**
		 * Admin Scripts
		 *
		 * @param $hook
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function admin_enqueue( $hook ) {

			//admin styles
			wp_enqueue_style( 'radio-player-admin', RADIO_PLAYER_ASSETS . '/css/admin.css', [ 'wp-components' ], RADIO_PLAYER_VERSION );

			/**---- admin scripts -----*/

			if ( in_array( $hook, [ 'index.php', 'radio_page_statistics' ] ) ) {
				wp_enqueue_script( 'radio-player-chart', RADIO_PLAYER_ASSETS . '/vendor/Chart.bundle.min.js', ['jquery-ui-datepicker'] );
			}

			//radio player admin
			wp_enqueue_script( 'radio-player-admin', RADIO_PLAYER_ASSETS . '/js/admin.min.js', array(
				'wp-element',
				'wp-components',
				'wp-block-editor',
				'wp-api-fetch',
				'wp-util',
			), RADIO_PLAYER_VERSION, true );

			wp_localize_script( 'radio-player-admin', 'radioPlayer', array(
				'is_admin'    => is_admin(),
				'site_url'    => site_url(),
				'plugin_url'  => RADIO_PLAYER_URL,
				'admin_url'   => admin_url(),
				'upgrade_url' => rp_fs()->get_upgrade_url(),
				'ajax_url'    => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wp_rest' ),
				'i18n'        => array(),
				'isPro'       => rp_fs()->can_use_premium_code__premium_only(),
				'settings'    => (array) get_option( 'radio_player_settings' ),
				'isHTTP'      => empty( $_SERVER['HTTPS'] ) || 'off' == $_SERVER['HTTPS'],
				'userIP'      => radio_player_get_user_ip(),
			) );


		}

		public function elementor_scripts() {
			wp_enqueue_script( 'radio-player-elementor', RADIO_PLAYER_ASSETS . '/js/elementor.min.js', [ 'jquery' ], RADIO_PLAYER_VERSION, true );
		}

		/**
		 * @return Radio_Player_Enqueue|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}
}

Radio_Player_Enqueue::instance();




