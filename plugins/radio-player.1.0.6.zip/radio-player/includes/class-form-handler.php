<?php

defined( 'ABSPATH' ) || exit();


if ( ! class_exists( 'Radio_Player_Form_Handler' ) ) {
	class Radio_Player_Form_Handler {

		/** @var null */
		private static $instance = null;

		/**
		 * Radio_Player_Form_Handler constructor.
		 */
		public function __construct() {}



		/**
		 * @return Radio_Player_Form_Handler|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}

}

Radio_Player_Form_Handler::instance();