<?php

defined( 'ABSPATH' ) || exit;

require_once RADIO_PLAYER_INCLUDES . '/class-rest-api-controller.php';

if ( ! class_exists( 'Radio_Player_Rest_Api' ) ) {
	class Radio_Player_Rest_Api {
		/** @var null */
		private static $instance = null;

		/**
		 * Radio_Player_Rest_Api constructor.
		 *
		 */
		public function __construct() {
			add_action( 'rest_api_init', [ $this, 'register_api' ] );
		}

		/**
		 * Register rest API
		 *
		 * @since 1.0.0
		 */
		public function register_api() {
			$controller = Radio_Player_Rest_Api_Controller::instance();

			$controller->register_routes();
		}

		/**
		 * @return Radio_Player_Rest_Api|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}

}

Radio_Player_Rest_Api::instance();