<?php

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'Radio_Player_Shortcode' ) ) {
	class Radio_Player_Shortcode {

		/**
		 * @var null
		 */
		private static $instance = null;

		/**
		 * Radio_Player_Shortcode constructor.
		 */
		public function __construct() {
			add_shortcode( 'radio_player', array( $this, 'player' ) );
		}

		/**
		 * @param $atts
		 *
		 * @return false|string
		 * @since 1.0.0
		 */
		public function player( $atts ) {

			$atts = shortcode_atts( array(
				'id'          => '',
				'player_type' => 'shortcode',
			), $atts );

			ob_start();

			$id          = $atts['id'];
			$player_type = $atts['player_type'];
			$skin        = radio_player_get_meta( $id, 'skin', 'skin1' );

			$stations       = radio_player_get_meta( $id, 'stations' );
			$popup_icon     = radio_player_get_meta( $id, 'popup_icon', 'off' );
			$playlist_icon  = radio_player_get_meta( $id, 'playlist_icon', 'off' );
			$volume_control = radio_player_get_meta( $id, 'volume_control', 'on' );
			$player_status  = radio_player_get_meta( $id, 'player_status', 'on' );
			$autoplay       = radio_player_get_meta( $id, 'autoplay', 'off' );
			$width          = radio_player_get_meta( $id, 'width', '300' );
			$border_radius  = radio_player_get_meta( $id, 'border_radius', '5' );
			$bg_color       = radio_player_get_meta( $id, 'bg_color' );
			$bg_type        = radio_player_get_meta( $id, 'bg_type' );
			$bg_image       = radio_player_get_meta( $id, 'bg_image' );
			$text_color     = radio_player_get_meta( $id, 'text_color' );
			$primary_color  = radio_player_get_meta( $id, 'primary_color' );
			$btn_color      = radio_player_get_meta( $id, 'btn_color' );


			ob_start(); ?>

            <div class="radio_player"
                 data-id="<?php echo $id; ?>"
                 data-playerType="<?php echo $player_type; ?>"
            ></div>

            <script type="application/json" id="radio_player_script_<?php echo $id; ?>">
                {
                 "skin": "<?php echo $skin; ?>",
                 "popup_icon": "<?php echo $popup_icon; ?>",
                 "playlist_icon": "<?php echo $playlist_icon; ?>",
                 "volume_control": "<?php echo $volume_control; ?>",
                 "player_status": "<?php echo $player_status; ?>",
                 "autoplay": "<?php echo $autoplay; ?>",
                 "width": "<?php echo $width; ?>",
                 "border_radius": "<?php echo $border_radius; ?>",
                 "bg_color": "<?php echo $bg_color; ?>",
                 "bg_type": "<?php echo $bg_type; ?>",
                 "bg_image": "<?php echo $bg_image; ?>",
                 "text_color": "<?php echo $text_color; ?>",
                 "primary_color": "<?php echo $primary_color; ?>",
                 "btn_color": "<?php echo $btn_color; ?>",
                 "stations": <?php echo radio_player_escape_quote( json_encode( $stations ) ); ?>
                }


            </script>

			<?php
			return ob_get_clean();
		}

		/**
		 * @return Radio_Player_Shortcode|null
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}
}

Radio_Player_Shortcode::instance();