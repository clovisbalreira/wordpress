<?php

defined( 'ABSPATH' ) || exit();

class Radio_Player_Update_1_0_2 {

	private static $instance = null;

	public function __construct() {
		$this->update_stations();
	}

	public function update_stations() {
		$posts = get_posts( [
			'post_type'   => 'radio',
			'numberposts' => 99,
		] );

		if ( ! empty( $posts ) ) {

			foreach ( $posts as $post ) {
				$stations = [];
				$post_id = $post->ID;

				$title     = $post->post_title;
				$thumbnail = radio_player_get_meta( $post_id, 'thumbnail', RADIO_PLAYER_ASSETS . '/images/placeholder.png' );
				$stream    = radio_player_get_meta( $post_id, 'stream_url' );

				$stations[] = [
					'title'     => $title,
					'thumbnail' => $thumbnail,
					'stream'    => $stream
				];

				update_post_meta( $post_id, 'stations', $stations );

			}

		}

	}

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


}

Radio_Player_Update_1_0_2::instance();