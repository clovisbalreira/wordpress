<?php

defined( 'ABSPATH' ) || exit();

class Radio_Player_Update_1_0_1 {

	private static $instance = null;

	public function __construct() {
		$this->update_player_thumbnails();
	}

	public function update_player_thumbnails() {
		$posts = get_posts( [
			'post_type'   => 'radio',
			'numberposts' => 20,
		] );

		if ( ! empty( $posts ) ) {
			foreach ( $posts as $post ) {
				$thumbnail_url = get_the_post_thumbnail_url( $post );

				if ( ! empty( $thumbnail_url ) ) {
					update_post_meta( $post->ID, 'thumbnail', $thumbnail_url );
					delete_post_meta($post->ID, '_thumbnail_id' );
				}

			}
		}

	}

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


}

Radio_Player_Update_1_0_1::instance();