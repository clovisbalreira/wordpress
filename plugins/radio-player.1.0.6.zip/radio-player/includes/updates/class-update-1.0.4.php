<?php

defined( 'ABSPATH' ) || exit();

class Radio_Player_Update_1_0_4 {

	private static $instance = null;

	public function __construct() {
		$this->create_tables();
	}

	public function create_tables() {
		global $wpdb;
		$wpdb->hide_errors();
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		$tables = [

			//statistics table
			"CREATE TABLE IF NOT EXISTS {$wpdb->prefix}radio_player_statistics(
         	id bigint(20) NOT NULL AUTO_INCREMENT,
			player_id bigint(20) NOT NULL,
         	unique_id varchar (32) NOT NULL DEFAULT '',
			`count` bigint(20) NOT NULL DEFAULT '1',
			user_ip varchar(128)  NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY `unique_id` (`unique_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;",

		];

		foreach ( $tables as $table ) {
			dbDelta( $table );
		}
	}

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


}

Radio_Player_Update_1_0_4::instance();