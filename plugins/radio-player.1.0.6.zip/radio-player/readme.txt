=== Radio Player - Live Shoutcast, Icecast and Audio Stream Player for Wordpress ===
Contributors: wpmilitary, princeahmed
Tags: block, blocks, gutenberg blocks, shoutcast, icecast, audio, player, radio player, mp3
Requires at least: 5.0
Tested up to: 5.8
Requires PHP: 5.6
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple, easy to use, user friendly and fully customizable web radio player for WordPress. You can play any live mp3, iceCast and Shoutcast stream in your WordPress website using shortcode, gutenberg block, elementor widget, sidebar widget, full-width sticky & popup player.

== Description ==

A simple, easy to use, user friendly and fully customizable web radio player for WordPress.

You can play any live mp3, iceCast and Shoutcast stream in your WordPress website using shortcode, gutenberg block, elementor widget, sidebar widget, full-width sticky and popup player.

== VIDEO OVERVIEW ==
https://youtu.be/05AHvgrmsTc

== DEMO ==
 👁️ [View Demo](https://wpmilitary.com/radio-player#demo) | 🚀 [Get PRO](https://checkout.freemius.com/mode/dialog/plugin/8684/plan/14508/)

== RADIO PLAYER FEATURES: ==

* **Multiple Radio Stations** - You can add multiple radio stations with title, stream url and thumbnail. Users can play the stations by using the next/ previous buttons.
* **Stations Playlist** - Users can choose and play any station from the radio stations playlist of the player.
* **Full-width Sticky Player** - Full-width sticky player is available to play a radio station in all page.
* **Specific Pages Sticky Player** - You can display the sticky-player in the specific pages where you want.
* **Play Statistics** - You can view the statistics how many user how many times the radio player.
* **Multiple Player Skins** - Multiple player skins available.
* **Player Duplicator** - You can duplicate any radio player with all the configurations.
* **Live Player Editing Preview** - Realtime player preview in the player editing screen
* **HTTP Stream Player** - You can play a HTTP radio stream in a HTTPS website.
* **Popup Player** - Popup radio player is available to play the radio in a new popup window for a better listening experience for the user.
* **Customize Popup Player Size** - You customize the popup player width & height.
* **M3U8 stream link supports** - You can play the live .m3u8 streams using the radio player.
* **Multiple Instance** - You can use multiple radio player in a single page.
* **Station Metadata** -Radio player can grap and play the current playing station metadata title.
* **Continuous Playing** -Automatically starts playing after every page reload.
* **Add Unlimited Players** - You can add unlimited radio players as you want.
* **Color Customizations** - Color customizations available for customizing the radio player.
* **Shortcode Player** - Display and play the radio player anywhere using the `[radio_player]` shortcode.
* **Sidebar Player Widget** - Display and play the radio player in any sidebar using the radio player widget.
* **Gutenberg Block** - Display and play the radio player in any page/ post using the radio player gutenberg block.
* **Elementor Widget** - Display and play the radio player in any page/ post using the radio player elementor widget.

== ADD NEW PLAYER: ==
After installing and activating the plugin successfully, The next step is to add new players.
You can add unlimited new players very easily.

For adding a new players you have to navigate to the **Add New Player** submenu under the Radio Player main menu.

You would find the below options in the add new radio player page:

* **Radio Stations** - You can add multiple radio stations with title, stream url and thumbnail. Users can play the stations by using the next/ previous buttons.
* **Popup Icon** - The popup player opener icon. You can show/ hide the popup player icon in the player.
* **Playlist Icon** - You can show/ hide the playlist icon in the player.
* **Autoplay** - You can control the autoplay settings of the radio player.
* **Volume Control** - The volume control button. You can show/hide the volume control button.
* **Player Status** - The live/ offline indicator status for the player. You can show/hide the player status in the player.
* **Player Width** - The radio player width. You can customize the with of the radio player.
* **Border Radius** - The player rounded border-radius. You can customize this option too.
* **Primary Color** - The player primary color.
* **Background Color** - The player background color.
* **Text Color** - The player text color.
* **Button Color** - The player button color.
* **Use as Sticky Player** - If this option is ON the player will be displayed as a full-width sticky player at the footer of every page.
* **Preview** - You can preview the radio player while you are adding it.

== USAGE: ==

1. After you have successfully activated the plugin, Radio Player menu will appear in your WordPress dashboard sidebar menu.

2. You can add unlimited radio player from the Add New Player page.

3. You can use the [radio_player id="player_id"] shortcode, gutenberg radio player block, elementor radio player widget, native sidebar radio player widget, full-width sticky player and popup player.


== SHORT CODES: ==

The Plugin provides a shortcode for displaying the radio player anywhere as you want.

* **`[radio_player]`** - **Example:** `[radio_player id="player_id"]` , replace the **player_id** with the ID of the player that you want display.


 == Compatibility ==

Radio Player has no dependency on any other plugin or theme. You can use the Radio Player plugin with any theme.


== 🔥 WHAT’S NEXT ==
If you like this Radio Player plugin, then consider checking out our other project if you want to make a worldwide radio station directory website:

* [WP Radio - Worldwide Radio Station Directory](https://wordpress.org/plugins/wp-radio) - WP Radio is a worldwide radio station directory plugin for WordPress to play 52000+ online radio stations from all the countries over the world.

 == Frequently Asked Questions ==

= How Can I add Multiple Radio Stations? =
You can add multiple radio stations for a single player in the PRO version. Users can play them by using the next/ previous buttons.

= When I clicked play, there is no sound? =

Most of the radio station stream links are HTTP (Unsecured) that can't be played on HTTPS (Secured) website because of browser mixed-content restrictions.
Modern browsers no longer accepts mixed requests.
Please check this link:
[https://web.dev/what-is-mixed-content](https://web.dev/what-is-mixed-content)

To play the HTTP streams in a HTTPS website, you need to upgrade to PRO.

= How can I us the footer full-width sticky player? =
To set the radio player fixed to the footer as a full-width sticky player, you need to check the use as sticky player checkbox in player editing screen.



== Screenshots ==
1. Add New Radio Player Screen
1. Player Skin 1
1. Player Skin 2
1. Player Skin 3
1. Player Skin 4
1. Player Skin 5
1. Player Skin 6
1. Full-width sticky Player
2. Radio Player Settings Page
3. Elementor Radio Player Widget
4. Gutenberg Radio Player Block
5. Sidebar Widget Radio Player

== Changelog ==

= 1.0.6 =
* New: Add play count column to the player list table
* Fix: Fixed WordPress compatibility check
* Fix: Fixed current track title display
* Fix: Fixed HTTP stream player
* Remove: Removed track artist supports

= 1.0.5 =
* New: Add 2 new player skins
* New: Add track artist display
* New: Player background image support
* Fix: Fixed .m3u8 stream player
* Fix: Fixed admin dashboard responsive design

= 1.0.4 =
* Fix: Fixed .m3u8 stream player
* New: Added sticky player display page selection
* New: Radio player statistics dashboard widget and page

= 1.0.3 =
* New: Add station playlist
* Fix: Fixed showing current station metadata title
* Fix: Fixed HTTP stream player

= 1.0.2 =
* New: Added radio player duplicator
* New: Added multiple radio stations supports for the player
* New: Added next/ previous buttons on the radio player
* Fix: Fixed WordPress core screen options and help not working issue
* Fix: Fixed rado player sync issue

= 1.0.1 =
* New: Added HTTP stream player
* New: Added settings page
* New: Added default player volume settings
* New: Added popup player size settings
* New: Added real-time player preview while editing
* New: Added multiple player skins
* Improvement: Updated the radio player to react js for better user experience
* Improvement: Improved the whole plugin UI design

= 1.0.0 (24 June,2021) =
* Initial release