(function($){
	$(function(){
		$('.color-picker').wpColorPicker();
	});
})(jQuery);