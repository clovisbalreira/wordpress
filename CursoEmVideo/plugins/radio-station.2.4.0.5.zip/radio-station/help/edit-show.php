<?php
/*
 * Help file for edit-show page
 * Author: Andrew DePaula
 * (c) Copyright 2020
 * Licence: GPL3
 */
?>
<style type="text/css">
  mark.w-red {
    color: red;
    background: none;
  }
  mark.warning{
    font-weight: bold;
    background: none;
  }
</style>

<h1>Managing Shows</h1>
<p>
  This is where you put help on managing shows...
</p>
