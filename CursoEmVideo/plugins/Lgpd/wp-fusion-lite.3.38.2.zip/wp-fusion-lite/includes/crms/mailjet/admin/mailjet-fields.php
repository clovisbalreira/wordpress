<?php

$mailjet_fields = array();

$mailjet_fields['first_name'] = array(
	'crm_label' => 'Name',
	'crm_field' => 'Name'
);

$mailjet_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'Email'
);