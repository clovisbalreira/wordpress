<?php

$zoho_fields = array();

$zoho_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'First_Name'
);

$zoho_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'Last_Name'
);

$zoho_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'Email'
);

$zoho_fields['billing_address_1'] = array(
	'crm_label' => 'Mailing Street',
	'crm_field' => 'Mailing_Street'
);

$zoho_fields['billing_city'] = array(
	'crm_label' => 'Mailing City',
	'crm_field' => 'Mailing_City'
);

$zoho_fields['billing_state'] = array(
	'crm_label' => 'Mailing State',
	'crm_field' => 'Mailing_State'
);

$zoho_fields['billing_postcode'] = array(
	'crm_label' => 'Mailing Postal Code',
	'crm_field' => 'Mailing_Zip'
);

$zoho_fields['billing_country'] = array(
	'crm_label' => 'Mailing Country',
	'crm_field' => 'Mailing_Country'
);

$zoho_fields['phone_number'] = array(
	'crm_label' => 'Home Phone',
	'crm_field' => 'Home_Phone'
);

$zoho_fields['billing_phone'] = array(
	'crm_label' => 'Home Phone',
	'crm_field' => 'Home_Phone'
);