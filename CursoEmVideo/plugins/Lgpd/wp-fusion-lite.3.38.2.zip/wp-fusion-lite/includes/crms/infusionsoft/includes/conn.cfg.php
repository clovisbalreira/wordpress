<?php

$connInfo = array( 'connectionName:applicationName:i:APIKEYGOESHERE:This is the connection for applicationName.infusionsoft.com' );

?>