<?php

$platformly_fields = array();

$platformly_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name'
);

$platformly_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'last_name'
);

$platformly_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$platformly_fields['phone_number'] = array(
	'crm_label' => 'Phone',
	'crm_field' => 'phone'
);

$platformly_fields['billing_address_1'] = array(
	'crm_label' => 'Address 1',
	'crm_field' => 'address'
);

$platformly_fields['billing_address_2'] = array(
	'crm_label' => 'Address 2',
	'crm_field' => 'address2'
);

$platformly_fields['billing_city'] = array(
	'crm_label' => 'City',
	'crm_field' => 'city'
);

$platformly_fields['billing_state'] = array(
	'crm_label' => 'State',
	'crm_field' => 'state'
);

$platformly_fields['billing_postcode'] = array(
	'crm_label' => 'Zip',
	'crm_field' => 'zip'
);

$platformly_fields['billing_country'] = array(
	'crm_label' => 'Country',
	'crm_field' => 'country'
);

$platformly_fields['company'] = array(
	'crm_label' => 'Company',
	'crm_field' => 'company'
);

$platformly_fields['website'] = array(
	'crm_label' => 'Website',
	'crm_field' => 'website'
);

$platformly_fields['user_url'] = array(
	'crm_label' => 'Website',
	'crm_field' => 'website'
);

$platformly_fields['billing_country'] = array(
	'crm_label' => 'Country',
	'crm_field' => 'country'
);