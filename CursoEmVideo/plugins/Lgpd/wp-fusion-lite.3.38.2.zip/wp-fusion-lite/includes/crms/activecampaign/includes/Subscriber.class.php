<?php

class AC_Subscriber extends AC_Contact {
}

?>