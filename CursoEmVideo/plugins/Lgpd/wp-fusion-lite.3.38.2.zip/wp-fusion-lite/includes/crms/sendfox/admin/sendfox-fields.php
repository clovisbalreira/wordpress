<?php

$sendfox_fields = array();

$sendfox_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name'
);

$sendfox_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'last_name'
);

$sendfox_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$sendfox_fields['billing_first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name'
);

$sendfox_fields['billing_last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'last_name'
);

$sendfox_fields['billing_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);