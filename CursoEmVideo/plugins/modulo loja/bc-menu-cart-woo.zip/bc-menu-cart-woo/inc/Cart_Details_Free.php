<?php


namespace BinaryCarpenter\BC_MNC;
/**
 * Class Cart_Details
 * @package BinaryCarpenter\BC_MNC
 */
class Cart_Details {

	public static function generate_cart_items_list(BC_Options $design_options) { return ''; }
}