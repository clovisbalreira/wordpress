<?php
/**
 * Setup wizard no navigation template.
 *
 * @package    RankMath
 * @subpackage RankMath\Admin\Wizard
 */

defined( 'ABSPATH' ) || exit;

?>
<br>
<br>
